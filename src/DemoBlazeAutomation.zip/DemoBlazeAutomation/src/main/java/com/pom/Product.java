package com.pom;

import java.time.Duration;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Product {
    WebDriver driver;
    WebDriverWait wait;

    By samsungGalaxyS6 = By.xpath("//a[normalize-space()='Samsung galaxy s6']");
    By addToCart = By.xpath("//a[normalize-space()='Add to cart']");

    public Product(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void selectSamsungGalaxyS6() {
        wait.until(ExpectedConditions.elementToBeClickable(samsungGalaxyS6)).click();
    }

    public void clickAddToCart() {
        wait.until(ExpectedConditions.elementToBeClickable(addToCart)).click();
    }

    public void handleCartAlert() {
        wait.until(ExpectedConditions.alertIsPresent());
        Alert alert = driver.switchTo().alert();
        alert.accept();
    }
}