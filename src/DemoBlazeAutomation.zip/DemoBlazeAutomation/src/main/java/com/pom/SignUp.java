package com.pom;

import java.time.Duration;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SignUp {
    WebDriver driver;
    WebDriverWait wait;

    By signUpButton = By.id("signin2");
    By signUsername = By.id("sign-username");
    By signPassword = By.id("sign-password");
    By signUpConfirmButton = By.xpath("//button[text()='Sign up']");

    public SignUp(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void clickSignUp() {
        wait.until(ExpectedConditions.elementToBeClickable(signUpButton)).click();
    }

    public void enterSignUpUsername(String username) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(signUsername)).sendKeys(username);
    }

    public void enterSignUpPassword(String password) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(signPassword)).sendKeys(password);
    }

    public void clickConfirmSignUp() {
        wait.until(ExpectedConditions.elementToBeClickable(signUpConfirmButton)).click();
    }

    public void handleSignUpAlert() {
        wait.until(ExpectedConditions.alertIsPresent());
        Alert alert = driver.switchTo().alert();
        alert.accept();
    }
}