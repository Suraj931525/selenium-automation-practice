package com.pom;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Login {
    WebDriver driver;
    WebDriverWait wait;

    By loginButton = By.id("login2");
    By loginUsername = By.id("loginusername");
    By loginPassword = By.id("loginpassword");
    By loginConfirmButton = By.xpath("//button[text()='Log in']");
    By nameOfUserHeader = By.id("nameofuser");

    public Login(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void clickLogin() {
        wait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();
    }

    public void enterLoginUsername(String username) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(loginUsername)).sendKeys(username);
    }

    public void enterLoginPassword(String password) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(loginPassword)).sendKeys(password);
    }

    public void clickConfirmLogin() {
        wait.until(ExpectedConditions.elementToBeClickable(loginConfirmButton)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(nameOfUserHeader));
    }
}