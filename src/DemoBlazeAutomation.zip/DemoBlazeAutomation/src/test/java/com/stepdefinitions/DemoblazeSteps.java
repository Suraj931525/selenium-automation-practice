package com.stepdefinitions;

import com.base.setup;
import com.pom.Card;
import com.pom.Login;
import com.pom.Product;
import com.pom.SignUp;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;

public class DemoblazeSteps {

    SignUp signUpPage;
    Login loginPage;
    Product productPage;
    Card cardPage;

    String username = "User" + System.currentTimeMillis();
    String password = "Password123";

    @Before
    public void setupBrowser() {
        setup.initializeDriver();
        signUpPage = new SignUp(setup.driver);
        loginPage = new Login(setup.driver);
        productPage = new Product(setup.driver);
        cardPage = new Card(setup.driver);
    }

    @Given("User opens the Demoblaze application")
    public void user_opens_application() {
        // Driver is initialized in @Before hook
    }

    @When("User registers a new account")
    public void user_registers_new_account() {
        signUpPage.clickSignUp();
        signUpPage.enterSignUpUsername(username);
        signUpPage.enterSignUpPassword(password);
        signUpPage.clickConfirmSignUp();
        signUpPage.handleSignUpAlert();
    }

    @When("User logs in with the registered credentials")
    public void user_logs_in() {
        loginPage.clickLogin();
        loginPage.enterLoginUsername(username);
        loginPage.enterLoginPassword(password);
        loginPage.clickConfirmLogin();
    }

    @When("User selects a product and adds it to the cart")
    public void user_adds_product_to_cart() {
        productPage.selectSamsungGalaxyS6();
        productPage.clickAddToCart();
        productPage.handleCartAlert();
    }

    @When("User proceeds to cart and completes the purchase order")
    public void user_completes_purchase() {
        cardPage.goToCart();
        cardPage.clickPlaceOrder();
        cardPage.fillOrderDetails("Suraj", "India", "Pune", "1234567890123456", "12", "2026");
        cardPage.clickPurchase();
        cardPage.waitForFiveSecondsAndConfirmPurchase();
    }

    @Then("User logs out successfully")
    public void user_logs_out() {
        cardPage.clickLogout();
    }

    @After
    public void tearDown() {
        setup.quitDriver();
    }
}